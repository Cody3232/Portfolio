// Creates a dynamic greeting that changed depending on time of day

const greeting = document.querySelector('.hero h1');
const hour = new Date().getHours();

let greetingMessage = "Hi, I'm Cody Snow"; // Default message

if (hour < 12) {
  greetingMessage = "Good Morning, I'm Cody Snow";
} else if (hour < 18) {
  greetingMessage = "Good Afternoon, I'm Cody Snow";
} else {
  greetingMessage = "Good Evening, I'm Cody Snow";
}

// Set the greeting message to the h1 element
greeting.innerText = greetingMessage;
